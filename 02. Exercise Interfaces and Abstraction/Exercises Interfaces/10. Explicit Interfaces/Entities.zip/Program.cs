﻿using _10.Explicit_Interfaces.Core;

namespace _10.Explicit_Interfaces
{
    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
﻿public enum  Coin
{
    None = 0,
    One = 1,
    Two = 2,
    Five = 5,
    Ten = 10,
    Twenty = 20,
    Fifty = 50
}